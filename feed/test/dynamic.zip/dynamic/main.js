'use strict';

angular
	.module('app', ['ngRoute'])
	.config(function($routeProvider,  $locationProvider) {
		 $locationProvider.html5Mode(true);
		 
		var template = '<div>{{data}}</div>';
		$routeProvider
			.when('/', {
				template: 'Index',
				controller: angular.noop
			})
			.when('/first', {
				template: template,
				controller: 'FirstCtrl'
			})
			.when('/second', {
				template: template,
				controller: 'SecondCtrl'
			})
			.otherwise({redirectTo: '/'})
	})
	.controller('FirstCtrl', function($scope) {
		$scope.data = 'Hello from first controller';
	})
	.controller('SecondCtrl', function($scope) {
		$scope.data = 'Hello from second controller';
	});
